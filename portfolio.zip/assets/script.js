// HTML content for each page
const pages = {
  about: `
    <section class="page-about">
      <h1>About</h1>
      <p>Write your introduction here.</p>
    </section>
  `,
  portfolio: `
    <section class="page-portfolio">
      <h1>Portfolio</h1>
      <p>List your projects here.</p>
    </section>
  `,
  contact: `
    <section class="page-contact">
      <h1>Contact</h1>
      <p>Add your contact details or a form here.</p>
    </section>
  `
};

const DEFAULT_PAGE = "about";

// Displays the selected page, updates the URL hash, and sets the active nav link
function loadPage(pageName) {
  // Get page name from argument, URL hash, or default to "about"
  const name = pageName || window.location.hash.replace("#", "") || DEFAULT_PAGE;
  const content = pages[name];

  // Fallback if the page doesn't exist
  if (!content) {
    console.warn(`No page found for "${name}", loading default instead.`);
    return loadPage(DEFAULT_PAGE);
  }

  // Insert the HTML content into the main container
  const main = document.getElementById("maincontent");
  main.innerHTML = content;

  // Update URL hash if it doesn't match
  if (window.location.hash !== `#${name}`) {
    window.location.hash = name;
  }

  // Highlight the active navigation link
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.toggle("active", link.dataset.page === name);
  });

  // Scroll smoothly back to the top
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// Handle clicks on navigation links
document.querySelectorAll(".nav-link[data-page]").forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    loadPage(link.dataset.page);
  });
});

// Handle browser back/forward buttons
window.addEventListener("hashchange", () => loadPage());

// Load the initial page when the website finishes loading
document.addEventListener("DOMContentLoaded", () => loadPage());